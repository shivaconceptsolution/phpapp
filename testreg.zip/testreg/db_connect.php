<?php
$servername = "database-3.ctoceui6cb8o.ap-south-1.rds.amazonaws.com";
$username = "admin";
$password = "Test12345";
$dbname = "regdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
